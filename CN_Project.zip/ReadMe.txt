



--------------------------------------------------------------------------------------------------------
      RUN THE RECEIVER CODE USING THE FOLLOWING PROCEDURE    THE SERVER
--------------------------------------------------------------------------------------------------------
o Open the LINUX terminal.
o Change the directory to the location where you have saved your file Receiver.c
o Now think of a file name let's suppose ABC for making the exe file.
o Type gcc -o ABC Receiver.c 
o Now type ./ABC port_number
o port_number is the decided port between server and client.
o file_name is received at the receiver side with the name "video_copy"
---------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------
      RUN THE SENDER CODE USING THE FOLLOWING PROCEDURE       THE CLIENT
--------------------------------------------------------------------------------------------------------
o Open the LINUX terminal.
o Change the directory to the location where you have saved your file Sender.c
o Now think of a file name let's suppose abc for making the exe file.
o Type gcc -o abc Sender.c -lm
o Now type ./abc IPaddress port_number file_name
	o IPaddress is the IP address of your PC on the network.
	o port_number is the decided port between server and client.
	o file_name is the name of the file you wish to send to the receiver.
o Your file will be sent to the receiver.
---------------------------------------------------------------------------------------------------------
