//While running the file please enter the port number to be used for connection.
//UDPSERVER
//Khadija Kamran
//Haleema Khan

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <strings.h>
#include <string.h>

//BUFFERT is the size of the data to be sent in a single packet.--------------------------------------------
#define BUFFERT 500

//functions declared that creates a socket
int create_server_socket (int port);

//declaring structures:
struct sockaddr_in sock_serv,clt;

//---------------------------------------------------------------------------------------------------------

//creating our own structure of packets. 
//Now the size of a structure packet becomes = BUFFERT+int = 500+4 = 504
struct UDP_Packet{
int seq;
char data[BUFFERT];
};
//------------------------------------------------------------------------------------------------------------

//starting the main function which takes inputs from command prompt
// argv[1] = port
int main (int argc, char*argv[]){
    
	//declaring data types for the variables used-----------------------------------------------------------
	int fd, sfd,total_packets,packet_size,end,pkt_in_window;
	char buf[BUFFERT];
	char filename[256];
	sprintf(filename,"videoCopy");
	unsigned int l;
	
	//for timing
	struct timeval tv;
	tv.tv_sec=5;
	tv.tv_usec=0;
	off_t count=0, n,lastPacket; // long type
	l=sizeof(struct sockaddr_in);
	//--------------------------------------------------------------------------------------------------------

	//the check if the user has input the correct values at the terminal   
	if (argc != 2){
        	printf("Error usage : %s <port_serv>\n",argv[0]);
        	return EXIT_FAILURE;
    	}
	//--------------------------------------------------------------------------------------------------------


	//creating the socket against the port number for the IP address
	sfd = create_server_socket(atoi(argv[1]));
	
	//---------------------------------------------------------------------------------------------------
    
	//checking if the file is opened properly
	if((fd=open(filename,O_CREAT|O_WRONLY|O_TRUNC,0600))==-1){
        	perror("open fail");
        	return EXIT_FAILURE;
	}
	//----------------------------------------------------------------------------------------------------

	//Receiveing the total number of packets and creating an array of that size and declaring a packet of type UDP struct
	recvfrom(sfd,&total_packets,4,0,(struct sockaddr *)&clt,&l);
	printf("The total number of pacckets are: %d\n",total_packets);
	struct UDP_Packet ordered_packets[5],packet;
	//----------------------------------------------------------------------------------------------------

	//Receiveing packets from the sender and filling the array ordered_packets
	end=0;
	while(!end){	
		for(pkt_in_window=0;pkt_in_window<=4;pkt_in_window++){
						
			packet_size=recvfrom(sfd,&packet,504,0,(struct sockaddr *)&clt,&l);
			if(packet_size!=0){
				printf("The packet %d has size: %d\n",packet.seq,packet_size);
			}
			if(packet_size==0){
				packet.seq=-1;
				ordered_packets[pkt_in_window] = packet;
				end=1;
				break;
			}

			ordered_packets[packet.seq%5]=packet;
			sendto(sfd,&packet.seq,4,0,(struct sockaddr*)&clt,l);
			printf("The acknowledgment of %d has been sent\n",packet.seq);
	   		
		}
		//----------------------------------------------------------------------------------------------------

		//writing the ordered packets to the file videoCopy

		for(int pkt=0;pkt<=pkt_in_window-1;pkt++){
			//indicating the packet just after the last packet
			if(ordered_packets[pkt].seq==-1){
				break;
			}
			if(ordered_packets[pkt].seq==total_packets){
				write(fd,&ordered_packets[pkt].data,packet_size-4);
			}
			else{
				write(fd,&ordered_packets[pkt].data,sizeof(ordered_packets[pkt].data));
			}
		}
		//-------------------------------------------------------------------------------------------------------
	    
	}
	printf("The file has been recieved!!\n");
	close(sfd);
	close(fd);
	return EXIT_SUCCESS;
}


//function that creates a socket from the port number!
int create_server_socket (int port){
    int l;
    int sfd;
   
    sfd = socket(AF_INET,SOCK_DGRAM,0);
    if (sfd == -1){
        perror("socket fail");
        return EXIT_FAILURE;
    }
   
    //preparation of the address of the destination socket. Assign an identity to the socket
 
    l=sizeof(struct sockaddr_in);
    bzero(&sock_serv,l);
   
    sock_serv.sin_family=AF_INET;
    sock_serv.sin_port=htons(port);
    sock_serv.sin_addr.s_addr=htonl(INADDR_ANY);
   
    //Assign an identity to the socket
    if(bind(sfd,(struct sockaddr*)&sock_serv,l)==-1){
        perror("bind fail");
        return EXIT_FAILURE;
    }
   
   
    return sfd;
}
