//While running the file please enter the server_IP,  server_port_number and the name of the file to be sent to the server.
//UDPCLIENT
//Khadija Kamran
//Haleema Khan

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <strings.h>
#include <string.h>
#include <math.h>


//BUFFERT is the size of the data to be sent in a single packet.--------------------------------------------
#define BUFFERT 500

//functions declared that creates a socket
int create_client_socket (int port, char* ipaddr);

//declaring structures:
struct sockaddr_in sock_serv,clt;

//---------------------------------------------------------------------------------------------------------

//creating our own structure of packets. 
//Now the size of a structure packet becomes = BUFFERT+int = 500+4 = 504
struct UDP_Packet{
int seq;
char data[BUFFERT];
};
//------------------------------------------------------------------------------------------------------------

//starting the main function which takes inputs from command prompt
// argv[1] = IP address
// argv[2] = port
// argv[3] = filename.mp4
int main (int argc, char*argv[]){

	//declaring data types for the variables used-----------------------------------------------------------
   	int sfd,fd,total_packets,l;   		//sfd is socket
	int end,seq_no,packet_size,pkt_in_window;        	//fd is file opened
				   		//ttlpcks is the total number of packets
						//l is the size of struct sockaddr_in
	int recvack;
	int ack[5] = {-1,-1,-1,-1,-1};		//array for checking the acks for one window packets
	char buf[BUFFERT];          		//array containing our packets
	off_t sz;        			//long sz is the size of the file  
	l=sizeof(struct sockaddr_in);
	struct stat buffer;
	
	
	
	//-------------------------------------------------------------------------------------------------
	
	//the check if the user has input the correct values at the terminal
	if (argc != 4){
		printf("Error usage : %s <ip_serv> <port_serv> <filename>\n",argv[0]);
		return EXIT_FAILURE;
	}
    
	//--------------------------------------------------------------------------------------------------

	//creating the socket against the port number for the IP address
	sfd=create_client_socket(atoi(argv[2]), argv[1]);
	
	//---------------------------------------------------------------------------------------------------
	
	//checking if the file is opened properly
	if ((fd = open(argv[3],O_RDONLY))==-1){
		perror("open fail");
		return EXIT_FAILURE;
	}
	//--------------------------------------------------------------------------------------------------

	//file size sz is being calculated
	if (stat(argv[3],&buffer)==-1){
		perror("stat fail");
		return EXIT_FAILURE;
	}
	else
		sz=buffer.st_size;

	//-----------------------------------------------------------------------------------------------------

	//finding the number of packets, sending as a packet, creating an array of 5 packets
	total_packets=ceil(sz/BUFFERT);
	sendto(sfd,&total_packets,sizeof(total_packets),0,(struct sockaddr*)&sock_serv,l);
	struct UDP_Packet array_of_packets[5],packet;
    
	//---------------------------------------------------------------------------------------------------	

	
	

	//Starting a loop on all the packets of array and sending 5 onnce in a window
	seq_no=0;
	end=0;
	while(!end){
		
		//populating the array_of_packets
		for(pkt_in_window=0; pkt_in_window<=4; pkt_in_window+=1){
		
			bzero(buf,BUFFERT);
			packet_size=read(fd, buf, BUFFERT);
			//for indicating the end of packets
			if(packet_size==0){
				packet.seq=-1;
				array_of_packets[pkt_in_window] = packet;
				end=1;
				break;
					
			}
			packet.seq=seq_no;
			memcpy(&packet.data,&buf, packet_size);
			array_of_packets[pkt_in_window] = packet;
			seq_no++;
		}
		//for sending the 5 packets populated in the array in previos loop 
		for(int i=0;i<=4;i++){
			int x=0;
			//for checking the end of the packets
			if(array_of_packets[i].seq==-1){
				break;
			}
			//for sending the last paccket of size  "(sz%500) + 4"	
			if(array_of_packets[i].seq==total_packets){
				x=sendto(sfd,&array_of_packets[i],(sz%500)+4,0,(struct sockaddr*)&sock_serv,l);
				printf("The packet %d has size %d\n",array_of_packets[i].seq,x);
				printf("The packet with sequence number %d is sent\n",array_of_packets[i].seq);//the sequence number of packet
			}
			else{
				x=sendto(sfd,&array_of_packets[i],sizeof(array_of_packets[i]),0,(struct sockaddr*)&sock_serv,l);
				printf("The packet %d has size %d\n",array_of_packets[i].seq,x);
				printf("The packet with sequence number %d is sent\n",array_of_packets[i].seq);//the sequence number of packet
			}
		}
		//The loop for receving ACKS from the 5 packets sent before
		for(int count=0; count<=pkt_in_window-1; count++){
			recvfrom(sfd,&recvack,4,0,(struct sockaddr *)&sock_serv,&l);	
			ack[recvack%5]=1;
			printf("The ack number %d is received\n",recvack);
		}


		//The loop does not exit until all the 5 ACKNOWLEDGEMENTS have been received.
		int count=1;
		while(count!=0){
			count=0;//count tells the total number of packets lost among the 5 packets
			for(int i=0;i<=pkt_in_window-1;i++){
				if(ack[i]==-1){
					count+=1;
					sendto(sfd,&array_of_packets[i],sizeof(array_of_packets[i]),0,(struct sockaddr*)&sock_serv,l);
					printf("Packet %d was lost hence resending...\n",array_of_packets[i].seq);
				}
			}

			for(int i=0; i<=count-1; i++){
				recvfrom(sfd,&recvack,4,0,(struct sockaddr *)&clt,&l);	
				ack[recvack%5]=1;
				printf("The ack number %d is received after resending\n",recvack);		
			}
		}
	}
	//sending the last packet having size 0 which will indicate the end of the file on the receiving side!!
	sendto(sfd,buf,0,0,(struct sockaddr*)&sock_serv,l);
	printf("The complete file has been transferred!!\n");
	close(sfd);
    	close(fd);
	return EXIT_SUCCESS;
	//---------------------------------------------------------------------------------------------------------
}


//function that creates a socket out of the port number and IPaddress!
int create_client_socket (int port, char* ipaddr){
    int l;
	int sfd;
	struct timeval tv;
    	tv.tv_sec=5;
    	tv.tv_usec=0;
	sfd = socket(AF_INET,SOCK_DGRAM,0);
	
	if (sfd == -1){
        perror("socket fail");
        return EXIT_FAILURE;
	}
    
	//preparation of the address of the destination
	l=sizeof(struct sockaddr_in);
	bzero(&sock_serv,l);
	
	sock_serv.sin_family=AF_INET;
	sock_serv.sin_port=htons(port);
	

	if (inet_pton(AF_INET,ipaddr,&sock_serv.sin_addr)==0){
		printf("Invalid IP adress\n");
		return EXIT_FAILURE;
	}
	if (setsockopt(sfd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv))< 0) {
		perror("Error");
	}
	
    
	return sfd;
}


